package ej6;

public interface Barcode_readable {
	public int get_barcode();
}
