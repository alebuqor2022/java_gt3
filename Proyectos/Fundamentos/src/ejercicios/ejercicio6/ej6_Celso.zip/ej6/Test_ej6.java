package ej6;

public class Test_ej6 {
	
	public static void main(String[] args) {
		test();
	}
	
	
	public static void test() {
		PC pc_1 = new PC(14, true, 123455);
		Silla silla_1 = new Silla(12, 2, true);
		
		System.out.println("ID PC:");
		System.out.println(pc_1.get_ID());
		
		System.out.println("ID Silla:");
		System.out.println(silla_1.get_ID());
		
		System.out.println("Barcode PC:");
		System.out.println(pc_1.get_barcode());
}
	
}
