package ej6;

public abstract class Item_inventario {
	public abstract int get_ID();
}
