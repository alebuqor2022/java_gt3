package ej6;

public class Silla extends Item_inventario {
	
	private int lote, numero_dentro_de_lote;
	private boolean con_rueditas;
	
	public Silla(int lote_, int numero_dentro_de_lote_, boolean con_rueditas_) {
		this.lote = lote_;
		this.numero_dentro_de_lote = numero_dentro_de_lote_;
		this.con_rueditas = con_rueditas_;
	}
	@Override
	public int get_ID() {
		// TODO Auto-generated method stub
		return lote*1000 + numero_dentro_de_lote;
	}

}
