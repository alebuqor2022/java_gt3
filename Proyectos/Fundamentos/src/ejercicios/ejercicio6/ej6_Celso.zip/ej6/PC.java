package ej6;

public class PC extends Item_inventario implements Barcode_readable {
	
	private int nro_serie, barcode;
	private boolean es_notebook;
	
	public PC(int nro_serie_, boolean es_notebook_, int barcode_) {
		this.nro_serie = nro_serie_;
		this.es_notebook = es_notebook_;
		this.barcode = barcode_;
	}

	@Override
	public int get_ID() {
		return nro_serie;		
	}

	@Override
	public int get_barcode() {
		return barcode;
	}
	

	

}
