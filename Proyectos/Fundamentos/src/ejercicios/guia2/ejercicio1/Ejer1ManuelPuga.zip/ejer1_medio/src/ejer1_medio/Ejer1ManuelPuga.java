package ejer1_medio;

import java.io.DataInputStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import java.util.StringTokenizer;
import java.util.stream.Collectors;

public class Ejer1ManuelPuga {
	public static void main(String[] args) {
		List<ShoppingArticle> arrayArticulos = new ArrayList<>();
		List<ShoppingArticle> listaDeFrutas = new ArrayList<>();
		List<ShoppingArticle> lista5MasCaros = new ArrayList<>();
		int cont=0;
		arrayArticulos = getDatosArchivo();
		// System.out.println(arrayArticulos);
		System.out.println("\nFruta mas barata: " + encontrarFrutaMasBarata(arrayArticulos).getNombre());
		
		System.out.println("\nVerdura mas barata: " + encontrarVegetalMasCaro(arrayArticulos).getNombre());
		System.out.println("\n");
		listaDeFrutas = enconstarFrutas(arrayArticulos);
		for (ShoppingArticle shoppingArticle : listaDeFrutas) {
			System.out.println("Fruta: " + shoppingArticle.getNombre()+"");
		}
		
		System.out.println("\n");
		lista5MasCaros = obtenerTop5ArticulosMasCaros(arrayArticulos);
		for (ShoppingArticle shoppingArticle : lista5MasCaros) {
			cont++;
			System.out.println(cont+"- Mas caro: " + shoppingArticle.getNombre());
		}

	}

	public static ShoppingArticle encontrarFrutaMasBarata(List<ShoppingArticle> lista) {
		ShoppingArticle frutaMasBarata = null;
		for (ShoppingArticle articulo : lista) {
			if (articulo.getCategoria().equals("Frutas")) {
				if (frutaMasBarata == null || articulo.getPrecio() < frutaMasBarata.getPrecio()) {
					frutaMasBarata = articulo;
				}
			}
		}
		return frutaMasBarata;
	}

	public static ShoppingArticle encontrarVegetalMasCaro(List<ShoppingArticle> lista) {
		ShoppingArticle vegetalMasCaro = null;
		for (ShoppingArticle articulo : lista) {
			if (articulo.getCategoria().equals("Verduras")) {
				if (vegetalMasCaro == null || articulo.getPrecio() > vegetalMasCaro.getPrecio()) {
					vegetalMasCaro = articulo;
				}
			}
		}
		return vegetalMasCaro;
	}

	public static List<ShoppingArticle> enconstarFrutas(List<ShoppingArticle> lista) {
		List<ShoppingArticle> listaDeFrutas = new ArrayList<>();
		for (ShoppingArticle articulo : lista) {
			if (articulo.getCategoria().equals("Frutas")) {
				listaDeFrutas.add(articulo);
			}
		}
		return listaDeFrutas;
	}

	public static List<ShoppingArticle> obtenerTop5ArticulosMasCaros(List<ShoppingArticle> arrayArticulos) {
		ArrayList<ShoppingArticle> listaArticulosOrdenadaPorPrecio = ((ArrayList<ShoppingArticle>) arrayArticulos
				.stream().sorted(Comparator.comparing(ShoppingArticle::getPrecio).reversed())
				.collect(Collectors.toList()));
		return listaArticulosOrdenadaPorPrecio.subList(0, 5);
	}

	public static List<ShoppingArticle> getDatosArchivo() {
		String s;
		List<ShoppingArticle> arrayArticulos = new ArrayList<>();
	
		ShoppingArticle articulo;
		ArrayList a;

		try {

			FileInputStream fs = new FileInputStream(
					"C:\\Users\\mpuga\\eclipse-workspace\\ejer1_medio\\auxiliar\\Datos.csv");
			DataInputStream ds = new DataInputStream(fs);

			while (true) {
				s = ds.readLine();
				if (s == null)
					break;
				StringTokenizer st = new StringTokenizer(s, ";");
				a = new ArrayList();
				articulo = new ShoppingArticle();
		
				while (st.hasMoreElements()) {

					String readToken = st.nextToken();
					a.add(readToken + "");

				}
				articulo.setNombre(a.get(0).toString());
				articulo.setPrecio(Double.parseDouble(a.get(1).toString()));
				articulo.setCategoria(a.get(2).toString());
				articulo.setUnidad(Integer.parseInt(a.get(3).toString()));
				arrayArticulos.add(articulo);

			}

			fs.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error en lectura de archivo.");
		}

		return arrayArticulos;
	}

}
