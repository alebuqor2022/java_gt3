package input_output_1;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Read_CSV {
	private String CSV_ruta, splitter;
	
	public Read_CSV(String CSV_ruta_, String splitter_) {
		this.CSV_ruta = CSV_ruta_;
		this.splitter = splitter_;
	}
	
	public List<Shooping_article> CSV_to_array_list() {
		final int col_nombre = 0; final int col_categoria = 1; final int col_precio = 2; final int col_unidad = 3;	
		String fila_CSV;
		String[] datos;
		List<Shooping_article> tabla = new ArrayList<>();
		
		try {
			FileInputStream CSV = new FileInputStream(CSV_ruta);
			DataInputStream Data = new DataInputStream(CSV);
			
			while(true) {
				fila_CSV = Data.readLine();
				
				if(fila_CSV == null)break;
				datos = fila_CSV.split(splitter);
				
				//Almacenamiento de objeto en ArrayList
				Shooping_article elemento = new Shooping_article();
				elemento.setNombre(datos[col_nombre]);
				elemento.setCategoria(datos[col_categoria]);
				elemento.setPrecio(Double.parseDouble(datos[col_precio]));
				elemento.setUnidad(Integer.parseInt(datos[col_unidad]));
				
				tabla.add(elemento);
							
				}
				CSV.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return tabla;
	}

}