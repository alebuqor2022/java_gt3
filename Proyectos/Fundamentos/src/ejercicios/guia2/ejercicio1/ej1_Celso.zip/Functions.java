package input_output_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Functions {
	public String get_objeto_caro(String categoria, List<Shooping_article> tabla) {
		double precio_mayor = 0;
		final int tamaño = tabla.size();
		String elemento_caro = "";
		
		for(int i = 0; i <= tamaño - 1; i++) {
			Shooping_article objecto = tabla.get(i);
			String categoria_objeto = objecto.getCategoria();
			
			if(categoria_objeto.equals(categoria)) {
				double precio = objecto.getPrecio();

				if (precio > precio_mayor) {
					elemento_caro = objecto.getNombre();
					precio_mayor = precio;
				}
			}		
		}
		return elemento_caro;	
}
	
	public String get_objeto_barato(String categoria, List<Shooping_article> tabla) {
		double precio_menor = 100000000;
		final int tamaño = tabla.size();
		String elemento_barato = "";
		
		for(int i = 0; i <= tamaño - 1; i++) {
			Shooping_article objecto = tabla.get(i);
			String categoria_objeto = objecto.getCategoria();
			
			if(categoria_objeto.equals(categoria)) {
				double precio = objecto.getPrecio();

				if (precio_menor > precio) {
					elemento_barato = objecto.getNombre();
					precio_menor = precio;
				}
			}		
		}
		return elemento_barato;
	}
	
	public List<String> get_elementos_categoria(String categoria, List<Shooping_article> tabla){
		List<String> elementos_categoria = new ArrayList();
		final int tamaño = tabla.size();
		
		for(int i = 0; i <= tamaño - 1; i++) {		
			Shooping_article objecto = tabla.get(i);
			String categoria_objeto = objecto.getCategoria();
			
			if(categoria_objeto.equals(categoria)) {
				String nombre_elemento = objecto.getNombre();
				elementos_categoria.add(nombre_elemento);
			}		
		}
		return elementos_categoria;	
	}
	
	public List<Double> order_precios(List<Shooping_article> tabla){
		List<Double> elementos_precio = new ArrayList();	
		final int tamaño = tabla.size();
		
		for(int i = 0; i <= tamaño - 1; i++) {
			
			Shooping_article objecto = tabla.get(i);
			Double precio_objeto = objecto.getPrecio();
			elementos_precio.add(precio_objeto);
		}
		Collections.sort(elementos_precio, Collections.reverseOrder());
		
		return elementos_precio;
	}
	
	public List<String> get_elementos_caros(List<Shooping_article> tabla){
		List<Double> elementos_precio = order_precios(tabla);
		final int numero_max_precios = 5;
		
		List<String> elementos_categoria = new ArrayList();
		final int tamaño = tabla.size();
		
		//Contador para almacenar 5 valores
		int j = 0;
		while (j < numero_max_precios) {
			for(int i = 0; i <= tamaño - 1; i++) {
				Shooping_article objecto = tabla.get(i);
				Double precio_objeto = objecto.getPrecio();
				if(precio_objeto.equals(elementos_precio.get(j))){
					elementos_categoria.add(objecto.getNombre());
				}
			}
			j++;
		}	
		return elementos_categoria;	
	}
}


