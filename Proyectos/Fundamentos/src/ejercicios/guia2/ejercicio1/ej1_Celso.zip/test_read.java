package input_output_1;

import java.util.List;

public class test_read {

	public static void main(String[] args) {
		Read_CSV read_CSV = new Read_CSV("C:\\Users\\cmrivas\\Desktop\\ejemplo.csv", ";");
		List<Shooping_article> tabla = read_CSV.CSV_to_array_list();
		
		Functions funciones = new Functions();
		
		System.out.println("Objeto más caro de la categoria alimentacion:");
		System.out.println(funciones.get_objeto_caro("alimentacion", tabla));
		
		System.out.println("Objeto más barato de la categoria alimentacion:");
		System.out.println(funciones.get_objeto_barato("alimentacion", tabla));
		
		System.out.println("Elementos de la categoria alimentacion:");
		System.out.println(funciones.get_elementos_categoria("alimentacion", tabla));
		
		System.out.println("5 Elementos más caros de la tabla CSV:");
		System.out.println(funciones.get_elementos_caros(tabla));
	}

}
