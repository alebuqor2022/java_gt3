package intermedioprimero;

import java.util.List;

public class ShoppingArticle {
	String nombre;
	String categoria;
	double precio;
	int unidad;
	public ShoppingArticle(String nombre, String categoria, double precio, int unidad) {
		this.categoria=categoria;
		this.nombre=nombre;
		this.precio= precio;
		this.unidad=unidad;
	}
	
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getUnidad() {
		return unidad;
	}
	public void setUnidad(int unidad) {
		this.unidad = unidad;
	}
}
