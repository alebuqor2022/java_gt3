package intermedioprimero;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ejercicio1 {
	String lamasbarata;
	public static void main(String[] args) throws IOException {
		System.out.println("Vamos a ver el csv");
		List<ShoppingArticle> list=LectorCsv.leerCSV("C:\\Users\\mcorbillon\\eclipse-workspace\\Fundamentos\\src\\intermedioprimero\\prueba.csv");
		
		System.out.println("La fruta más barata: "+ encontrarFrutaMasBarata(list).getNombre());
		System.out.println("La verdura más cara:"+ encontrarVegetalMasCostoso(list).getNombre());
		System.out.println("Las frutas son: "+ encontrarFrutas(list));
		System.out.println("Los cinco más caros: "+ encontrarCincoMasCaros(list));
		
		LectorCsv.agregarArticuloACSV("C:\\Users\\mcorbillon\\eclipse-workspace\\Fundamentos\\src\\intermedioprimero\\prueba.csv");
		
	}
	
	
	public static ShoppingArticle encontrarFrutaMasBarata(List<ShoppingArticle> shoppingList) {
	    ShoppingArticle frutaMasBarata = null;
	    for (ShoppingArticle article : shoppingList) {
	        if (article.getCategoria().equals("fruta")) {
	            if (frutaMasBarata == null || article.getPrecio() < frutaMasBarata.getPrecio()) {
	                frutaMasBarata = article;
	            }
	        }
	    }
	    return frutaMasBarata;
	}

	
	public static ShoppingArticle encontrarVegetalMasCostoso(List<ShoppingArticle> shoppingList) {
	    ShoppingArticle vegetalMasCostoso = null;
	    for (ShoppingArticle article : shoppingList) {
	        if (article.getCategoria().equals("vegetal")) {
	            if (vegetalMasCostoso == null || article.getPrecio() > vegetalMasCostoso.getPrecio()) {
	                vegetalMasCostoso = article;
	            }
	        }
	    }
	    return vegetalMasCostoso;
	}
	public static List<String> encontrarFrutas(List<ShoppingArticle> shoppingList) {
	    List<String> frutas = new ArrayList<>();
	    for (ShoppingArticle article : shoppingList) {
	        if (article.getCategoria().equals("fruta")) {
	            frutas.add(article.getNombre());
	        }
	    }
	    return frutas;
	}
	public static List<String> encontrarCincoMasCaros(List<ShoppingArticle> shoppingList) {
	    List<ShoppingArticle> cincoMasCaros = new ArrayList<>(shoppingList);
	    Collections.sort(cincoMasCaros, Comparator.comparing(ShoppingArticle::getPrecio).reversed());
	    List<String> nombresCincoMasCaros = new ArrayList<>();
	    for (int i = 0; i < 5; i++) {
	        nombresCincoMasCaros.add(cincoMasCaros.get(i).getNombre());
	    }
	    return nombresCincoMasCaros;
	}



	
	

}
