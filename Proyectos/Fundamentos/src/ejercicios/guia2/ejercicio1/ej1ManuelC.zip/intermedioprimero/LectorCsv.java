package intermedioprimero;
import java.io.*;
import java.util.*;

public class LectorCsv {
	public int num;
	public static List<ShoppingArticle> leerCSV(String nombreArchivo) throws IOException {
	    List<ShoppingArticle> shoppingList = new ArrayList<>();
	    BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
	    String line = "";
	    while ((line = br.readLine()) != null) {
	        StringTokenizer st = new StringTokenizer(line, ";");
	        String nombre = st.nextToken();
	        double precio = Double.parseDouble(st.nextToken());
	        String categoria = st.nextToken();
	        int unidad = Integer.parseInt(st.nextToken());
	        ShoppingArticle article = new ShoppingArticle(nombre, categoria, precio, unidad);
	        shoppingList.add(article);
	    }
	    br.close();
	    return shoppingList;
	}
	
	public static void agregarArticuloACSV(String csvFilePath) {
	    try {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Ingrese el nombre del artículo:");
	        String nombre = scanner.nextLine();
	        System.out.println("Ingrese la categoría del artículo:");
	        String categoria = scanner.nextLine();
	        System.out.println("Ingrese el precio del artículo:");
	        double precio = scanner.nextDouble();
	        System.out.println("Ingrese la unidad del artículo:");
	        int unidad = scanner.nextInt();
	        scanner.nextLine(); // Consumir la nueva línea después de la entrada de int

	        FileWriter csvWriter = new FileWriter(csvFilePath, true);
	        csvWriter.append(nombre);
	        csvWriter.append(";");
	        csvWriter.append(String.valueOf(precio));
	        csvWriter.append(";");
	        csvWriter.append(categoria);
	        csvWriter.append(";");
	        csvWriter.append(String.valueOf(unidad));
	        csvWriter.append("\n");
	        csvWriter.flush();
	        csvWriter.close();
	        System.out.println("Artículo agregado correctamente al archivo CSV.");
	    } catch (IOException e) {
	        System.out.println("Hubo un error al agregar el artículo al archivo CSV: " + e.getMessage());
	    }
	}


	
	
	
}
