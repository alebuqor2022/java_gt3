package io_2;

public class Test_cuenta {
	public static void main(String[] args) {
		Cuenta_corriente cuenta = new Cuenta_corriente(200, 500);
		cuenta.depositar(25.50);
		try {
			cuenta.retirar(148.25);
			cuenta.retirar(470);
			cuenta.retirar(300);
		}catch(Sobre_giro_exception e1) {
			System.out.println(e1.getMessage()+ e1.get_cantidad_deuda()+ "$");
		}
	}
}
