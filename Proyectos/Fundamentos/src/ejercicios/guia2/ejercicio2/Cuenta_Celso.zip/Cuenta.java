package io_2;

public class Cuenta {
	private double saldo;
	
	public Cuenta(double saldo_) {
		this.saldo = saldo_;
	}
	
	public void depositar(double cantidad) {
		saldo += cantidad;
		System.out.println("Depósito de " + cantidad + "$ realizada."); System.out.println("Saldo actual: " + saldo + "$");
	}
	
	public void retirar(double cantidad) throws Sobre_giro_exception {
		double deficit;
		if (saldo > cantidad) {
			saldo -= cantidad;
			System.out.println("Retirada de " + cantidad + " realizada."); System.out.println("Saldo actual: " + saldo + "$");
		}
		else {
			deficit = saldo - cantidad;
			throw new Sobre_giro_exception("Operación denegada, imposible quitar. Deficit:", deficit);
		}
	}


	public double getSaldo() {
		return saldo;
	}

}
