package io_2;

public class Sobre_giro_exception extends Exception {

	double cantidad_deuda;
	
	public Sobre_giro_exception(String mensaje_, double cantidad_deuda_) {
		super(mensaje_);
		this.cantidad_deuda = cantidad_deuda_;
	}
	
	public double get_cantidad_deuda() {
		return cantidad_deuda;
	}
}
