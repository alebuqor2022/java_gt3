package io_2;

public class Cuenta_corriente extends Cuenta {
	double sobre_giro;
	public Cuenta_corriente(double sobre_giro_, double saldo_) {
		super(saldo_ + sobre_giro_);
		this.sobre_giro = sobre_giro_;
	}
}
