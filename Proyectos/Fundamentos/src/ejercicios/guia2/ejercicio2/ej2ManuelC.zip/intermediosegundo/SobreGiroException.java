package intermediosegundo;

public class SobreGiroException extends Exception{
	public SobreGiroException(String message) {
		super(message);
	}
}