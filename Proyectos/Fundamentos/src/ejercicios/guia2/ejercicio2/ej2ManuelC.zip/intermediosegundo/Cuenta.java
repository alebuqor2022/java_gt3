package intermediosegundo;

public class Cuenta {

	private double saldo;
	private double sobreGiroAutorizado;
	
	public Cuenta(double saldoInicial, double sobreGiroAutorizado) {
		this.saldo=saldoInicial;
		this.sobreGiroAutorizado=sobreGiroAutorizado;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getSobreGiroAutorizado() {
		return sobreGiroAutorizado;
	}

	public void setSobreGiroAutorizado(double sobreGiroAutorizado) {
		this.sobreGiroAutorizado = sobreGiroAutorizado;
	}
	
	public void depositar(double monto) {
		saldo +=monto;
	}
	
	public void retirar(double monto) throws SobreGiroException{
		if(monto<=saldo+sobreGiroAutorizado) {
			saldo -= monto;
		}else {
			double deficit = monto - saldo - sobreGiroAutorizado;
			throw new SobreGiroException("Fondos insuficientes. Deficit de "+ deficit);
			
		}
	}
}

