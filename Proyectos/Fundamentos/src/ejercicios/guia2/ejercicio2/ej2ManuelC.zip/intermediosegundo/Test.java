package intermediosegundo;

public class Test {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Cuenta cuenta= new Cuenta(200,500);
		System.out.println("Saldo de la cuenta: "+cuenta.getSaldo());
		
		try {
			cuenta.retirar(148);
			System.out.println("Saldo despues de retirar: "+ cuenta.getSaldo());
			
			cuenta.retirar(500);
			System.out.println("Saldo despues de retirar por segunda vez: "+cuenta.getSaldo());
			
			cuenta.retirar(500);
			System.out.println("Saldo despues de retirar por tercera vez: "+cuenta.getSaldo());
		}catch(SobreGiroException e) {
			System.out.println(e.getMessage());
		}
	}

}
