package io_3;

public class hilo implements Runnable {

	String nombre_hilo;
	
	public hilo(String nombre_hilo_) {
		this.nombre_hilo = nombre_hilo_;
	}
	public void run() {
		final int min_veces = 10;
		System.out.println("Inicio hilo:" + nombre_hilo);
		try {
            for (int i = 0; i < min_veces; i++){
                Thread.sleep(2000);
                System.out.println("Hilo: "+ nombre_hilo+". Ejecución:" + i);
            }
        }catch (InterruptedException e1){
            System.out.println("Hilo:" + nombre_hilo + "interrupido por dispatcher.");
        }
		
	}

}
