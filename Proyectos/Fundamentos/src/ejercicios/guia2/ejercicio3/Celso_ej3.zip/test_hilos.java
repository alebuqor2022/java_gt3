package io_3;

public class test_hilos {
	public static void main(String[] args) {
		hilo hilo_1 = new hilo("Larry");
		hilo hilo_2 = new hilo("Moe");
		hilo hilo_3 = new hilo("Curly");
		
		Thread t_1 = new Thread(hilo_1);
		Thread t_2 = new Thread(hilo_2);
		Thread t_3 = new Thread(hilo_3);
		t_1.start();
		t_2.start();
		t_3.start();
	}
}
