package intermediotercero;

public class MiRunnable implements Runnable {
	public void run() {
		System.out.println(Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public MiRunnable() {

	}
}
