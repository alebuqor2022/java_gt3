package intermediotercero;

public class hilos {

	
	public static void main(String[] args) {
		MiRunnable miRunnable = new MiRunnable();
		Thread larry = new Thread(miRunnable);
		Thread moe = new Thread(miRunnable);
		Thread curly = new Thread(miRunnable);
		larry.setName("Larry");
		moe.setName("Moe");
		curly.setName("Curly");
		larry.start();
		for (int i = 0; i < 10; i++) {
			System.out.println(i);

			try {
				larry.sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Se cae aqui a la "+ i);
			}
		}
		moe.start();
		for (int i = 0; i < 10; i++) {
			System.out.println(i);

			try {
				moe.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		curly.start();
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
			try {
				curly.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
